import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Coffee, MapPin, Phone, Clock, Star, Heart, Music } from "lucide-react";
import { Button } from "@/components/ui/button";

// Images
import heroImg from "@assets/WhatsApp_Image_2026-02-20_at_00.02.50_1771836478174.jpeg";
import menuCardImg from "@assets/WhatsApp_Image_2026-02-20_at_00.02.44_1771836636917.jpeg";
import kulhadAnimeImg from "@/assets/images/kulhad-anime.png";
import menuTeaImg from "@/assets/images/menu-tea.png";
import menuSandwichImg from "@/assets/images/menu-sandwich.png";
import menuMaggiImg from "@/assets/images/menu-maggi.png";
import menuMocktailImg from "@/assets/images/menu-mocktail.png";
import gallery1Img from "@assets/WhatsApp_Image_2026-02-20_at_00.02.50_(1)_1771836478172.jpeg";
import gallery2Img from "@assets/WhatsApp_Image_2026-02-20_at_00.02.41_1771836491900.jpeg";
import gallery3Img from "@assets/WhatsApp_Image_2026-02-20_at_00.02.43_1771836491901.jpeg";
import storefrontImg from "@assets/WhatsApp_Image_2026-02-20_at_00.02.50_1771836478174.jpeg";

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [cozyMode, setCozyMode] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className={`min-h-screen bg-background text-foreground transition-colors duration-1000 ${cozyMode ? 'dark' : ''}`}>
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-background/90 backdrop-blur-md shadow-sm py-4 border-b border-border/50' : 'bg-transparent py-6'}`}>
        <div className="container mx-auto px-4 md:px-8 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Coffee className="h-8 w-8 text-primary" />
            <span className="font-heading font-bold text-2xl md:text-3xl tracking-tight text-primary text-glow">Baithack</span>
          </div>
          <div className="hidden md:flex gap-8 font-bold text-lg">
            <a href="#about" className="hover:text-primary transition-colors">About</a>
            <a href="#menu" className="hover:text-primary transition-colors">Menu</a>
            <a href="#gallery" className="hover:text-primary transition-colors">Gallery</a>
          </div>
          <Button variant="default" className="bg-primary text-primary-foreground hover:bg-accent font-bold rounded-full px-6 md:px-8">
            Order Now
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent z-10" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent z-10" />
          <img src={heroImg} alt="Cozy Cafe Interior" className="w-full h-full object-cover object-center" />
        </div>
        
        <div className="container mx-auto px-4 md:px-8 relative z-10 grid md:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
            className="flex flex-col gap-6 max-w-xl"
          >
            <motion.div variants={fadeIn} className="inline-block px-5 py-2 bg-primary/20 text-accent font-bold rounded-full w-fit border border-primary/30 backdrop-blur-sm">
              ✨ Kolhapur's Favorite Hangout
            </motion.div>
            <motion.h1 variants={fadeIn} className="text-5xl md:text-7xl font-bold leading-tight font-heading">
              Sip Warmth. <br/> <span className="text-primary text-glow">Taste Comfort.</span>
            </motion.h1>
            <motion.p variants={fadeIn} className="text-lg md:text-2xl opacity-90 leading-relaxed font-sans font-medium">
              Experience the cozy kulhad culture with delicious flavors and relaxing vibes in Kolhapur.
            </motion.p>
            <motion.div variants={fadeIn} className="flex flex-wrap gap-4 pt-4">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-accent rounded-full px-8 py-6 text-lg font-bold hover-glow shadow-xl shadow-primary/20">
                Explore Menu
              </Button>
            </motion.div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1, type: "spring" }}
            className="hidden md:flex justify-center relative"
          >
             <div className="absolute -inset-10 bg-primary/20 blur-3xl rounded-full" />
             <img src={kulhadAnimeImg} alt="Kulhad Tea Illustration" className="w-80 h-80 md:w-96 md:h-96 object-cover rounded-3xl box-glow border-4 border-primary/20 relative z-10" />
             
             {/* Floating steam particles */}
             <motion.div 
               animate={{ y: [0, -20, 0], opacity: [0.5, 1, 0.5] }}
               transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
               className="absolute top-[-20px] right-[20%] w-8 h-8 rounded-full bg-white/40 blur-md z-20"
             />
             <motion.div 
               animate={{ y: [0, -30, 0], opacity: [0.3, 0.8, 0.3] }}
               transition={{ repeat: Infinity, duration: 4, ease: "easeInOut", delay: 1 }}
               className="absolute top-[-40px] right-[40%] w-12 h-12 rounded-full bg-white/30 blur-lg z-20"
             />
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-card relative">
        <div className="container mx-auto px-4 md:px-8 max-w-4xl text-center">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="flex flex-col items-center gap-6"
          >
            <div className="p-4 bg-primary/10 rounded-full mb-2">
               <Coffee className="w-12 h-12 text-accent" />
            </div>
            <motion.h2 variants={fadeIn} className="text-4xl md:text-5xl font-bold font-heading">Your Cozy Corner</motion.h2>
            <motion.p variants={fadeIn} className="text-xl md:text-2xl leading-relaxed text-muted-foreground font-medium">
              Baithack is more than just a cafe — it's a cozy place known for authentic kulhad-style beverages, comforting food, and a relaxing ambience perfect for friends and family. Every corner is designed to make you feel at home.
            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* Menu Highlights */}
      <section id="menu" className="py-24 bg-background">
        <div className="container mx-auto px-4 md:px-8">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold font-heading mb-4">Our Menu</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-medium">Explore our wide range of delicious kulhad-style treats and comfort food.</p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="relative group bg-card rounded-3xl overflow-hidden hover-glow border border-border shadow-2xl"
            >
              <div className="aspect-[3/4] md:aspect-auto overflow-hidden">
                <img 
                  src={menuCardImg} 
                  alt="Baithack Menu Card" 
                  className="w-full h-auto object-contain transition-transform duration-700 group-hover:scale-[1.02]" 
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-8">
                <Button className="bg-primary text-primary-foreground font-bold rounded-full px-8 py-6">
                  View Full Menu
                </Button>
              </div>
            </motion.div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
              {[
                { title: "Kulhad Pizza", price: "Starting ₹120" },
                { title: "Sandwiches", price: "Starting ₹70" },
                { title: "Pasta Specials", price: "Starting ₹130" },
                { title: "Thick Shakes", price: "Starting ₹100" }
              ].map((item, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-6 bg-card rounded-2xl border border-border text-center"
                >
                  <h4 className="font-bold text-lg font-heading">{item.title}</h4>
                  <p className="text-primary font-bold mt-1">{item.price}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-card border-y border-border">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div 
               initial={{ opacity: 0, x: -50 }}
               whileInView={{ opacity: 1, x: 0 }}
               viewport={{ once: true }}
               className="relative"
            >
              <div className="absolute inset-0 bg-primary/20 rotate-6 rounded-3xl" />
              <img src={gallery1Img} alt="Cozy Ambience" className="relative rounded-3xl shadow-2xl object-cover aspect-square border-4 border-background" />
            </motion.div>
            
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="flex flex-col gap-8"
            >
              <div>
                <motion.h2 variants={fadeIn} className="text-4xl md:text-5xl font-bold font-heading mb-4">Why Choose Us</motion.h2>
                <motion.p variants={fadeIn} className="text-xl text-muted-foreground font-medium">The perfect ingredients for a memorable time.</motion.p>
              </div>
              
              <div className="grid sm:grid-cols-2 gap-6">
                {[
                  { icon: <Coffee className="w-8 h-8 text-accent"/>, title: "Unique Kulhad Experience", desc: "Authentic earthy flavors" },
                  { icon: <Heart className="w-8 h-8 text-accent"/>, title: "Warm Ambience", desc: "Golden lighting & cozy vibes" },
                  { icon: <Star className="w-8 h-8 text-accent"/>, title: "Affordable Pricing", desc: "Great taste, pocket friendly" },
                  { icon: <Music className="w-8 h-8 text-accent"/>, title: "Perfect Hangout Spot", desc: "Ideal for friends & family" }
                ].map((feature, i) => (
                  <motion.div key={i} variants={fadeIn} className="flex gap-4 items-start">
                    <div className="p-3 bg-background border border-border shadow-sm rounded-2xl shrink-0">
                      {feature.icon}
                    </div>
                    <div>
                      <h4 className="font-bold text-xl mb-1 font-heading">{feature.title}</h4>
                      <p className="text-muted-foreground font-medium">{feature.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section id="gallery" className="py-24 bg-background">
        <div className="container mx-auto px-4 md:px-8 text-center">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold font-heading mb-16"
          >
            Our Cozy Vibes
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[gallery1Img, gallery2Img, gallery3Img].map((img, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className={`rounded-3xl overflow-hidden shadow-lg border-4 border-card/50 ${i === 1 ? 'md:-translate-y-8' : ''}`}
              >
                <img src={img} alt="Cafe Vibe" className="w-full h-full object-cover aspect-[4/5] hover:scale-105 transition-transform duration-700" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-32 relative flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img src={gallery2Img} alt="Background" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-secondary/85 backdrop-blur-sm" />
        </div>
        
        <div className="relative z-10 container mx-auto px-4 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto text-secondary-foreground"
          >
            <h2 className="text-4xl md:text-6xl font-bold font-heading mb-8 leading-tight">
              Enjoying moments, conversations, and comfort.
            </h2>
            <p className="text-2xl md:text-3xl opacity-90 font-light italic text-primary/90">
              "The warmth of the kulhad matches the warmth of the memories made here."
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-card">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex flex-col justify-center"
            >
              <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6">Visit Us</h2>
              <p className="text-xl text-muted-foreground mb-12 max-w-md font-medium">
                Step into our warm cafe. Your cozy corner is waiting for you in Kolhapur.
              </p>
              
              <div className="space-y-8 mb-12">
                <div className="flex items-start gap-5">
                  <div className="p-4 bg-background border border-border shadow-sm rounded-2xl text-primary">
                    <MapPin className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="font-bold text-2xl font-heading">Location</h4>
                    <p className="text-muted-foreground mt-2 text-lg font-medium">Sarnaik Residency, 1st Lane, E Ward,<br/>Mahalaxminagar, Rajarampuri,<br/>Kolhapur, Maharashtra 416008</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-5">
                  <div className="p-4 bg-background border border-border shadow-sm rounded-2xl text-primary">
                    <Clock className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="font-bold text-2xl font-heading">Opening Hours</h4>
                    <p className="text-muted-foreground mt-2 text-lg font-medium">Monday – Sunday: 10:30 AM – 10:30 PM</p>
                  </div>
                </div>

                <div className="flex items-start gap-5">
                  <div className="p-4 bg-background border border-border shadow-sm rounded-2xl text-primary">
                    <Phone className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="font-bold text-2xl font-heading">Contact</h4>
                    <p className="text-muted-foreground mt-2 text-lg font-medium">0231 358 3949</p>
                  </div>
                </div>
              </div>
              
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative h-[500px] rounded-3xl overflow-hidden border-4 border-background shadow-2xl"
            >
              <img src={storefrontImg} alt="Cafe Storefront" className="w-full h-full object-cover hover:scale-105 transition-transform duration-1000" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-secondary-foreground py-12 border-t border-secondary/50">
        <div className="container mx-auto px-4 md:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <Coffee className="h-6 w-6 text-primary" />
            <span className="font-heading font-bold text-2xl tracking-tight text-primary">Baithack</span>
          </div>
          <p className="opacity-70 font-medium">© 2026 Baithack - Taste of Kulhad. All rights reserved.</p>
          <div className="flex gap-6 opacity-70 font-bold">
            <span className="hover:text-primary cursor-pointer transition-colors">Instagram</span>
            <span className="hover:text-primary cursor-pointer transition-colors">Facebook</span>
          </div>
        </div>
      </footer>

      {/* Floating Cozy Mode Toggle */}
      <button 
        onClick={() => setCozyMode(!cozyMode)}
        className="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-card/90 backdrop-blur-md border border-primary/30 px-5 py-4 rounded-full shadow-2xl hover:scale-105 hover:bg-card transition-all group box-glow"
        aria-label="Toggle Cozy Mode"
      >
        <span className="text-base font-bold font-heading text-primary opacity-0 w-0 group-hover:w-auto group-hover:opacity-100 overflow-hidden transition-all duration-300 whitespace-nowrap">
          {cozyMode ? "Normal Mode" : "Enter Cozy Mode"}
        </span>
        <span className="text-2xl">{cozyMode ? "☀️" : "☕"}</span>
      </button>

    </div>
  );
}